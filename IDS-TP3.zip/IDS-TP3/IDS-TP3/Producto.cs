﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDS_TP3
{
    public class Producto
    {
        public int ID { get; set; }
        public int Stock { get; set; }
        public Articulo Articulo { get; set; }
        public Talle Talle { get; set; }
        public Color Color { get; set; }
    }
}
