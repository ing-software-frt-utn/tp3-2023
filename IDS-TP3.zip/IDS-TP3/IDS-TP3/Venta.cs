﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDS_TP3
{
    public class Venta
    {
        public int NumVenta { get; set; }
        public DateTime Fecha { get; set; }
        public List<LineaDeVenta> LineasDeVenta { get; set; }

        public Venta()
        {
            LineasDeVenta = new List<LineaDeVenta>();
        }

        public double GetTotal()
        {
            double total = 0;
            foreach (var linea in LineasDeVenta)
            {
                total += linea.GetSubtotal();
            }
            return total;
        }

        public void AgregarProducto(Producto producto)
        {
            foreach (var linea in LineasDeVenta)
            {
                if (linea.Producto.ID == producto.ID)
                {
                    linea.Cantidad++;
                    return;
                }
            }
            LineasDeVenta.Add(new LineaDeVenta() { Cantidad = 1, Producto = producto });
        }

        public void QuitarProducto(int id)
        {
			for (int i=0; i<LineasDeVenta.Count; i++)
            {
                if (LineasDeVenta[i].Producto.ID == id)
                {
                    LineasDeVenta.RemoveAt(i);
                    break;
                }
            }
		}
    }
}
