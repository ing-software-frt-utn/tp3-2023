﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDS_TP3
{
    public class Articulo
    {
        public long Codigo { get; set; }
        public string Descripcion { get; set; }
        public double Costo { get; set; }
        public Marca Marca { get; set; }
        public Categoria Categoria { get; set; }
        public double MargenDeGanancia { get; set; }
        public double IVA { get; set; }

        public bool EsValido()
        {
            return Codigo >= 0 && !string.IsNullOrEmpty(Descripcion) && Costo > 0 && MargenDeGanancia>=0 && IVA > 0;
        }

        public double NetoGravado()
        {
            return Costo + Costo * MargenDeGanancia;
        }

        public double CostoIVA()
        {
            return NetoGravado() * IVA;
        }

        public double PrecioVenta()
        {
            return NetoGravado() + CostoIVA();
        }
    }
}
