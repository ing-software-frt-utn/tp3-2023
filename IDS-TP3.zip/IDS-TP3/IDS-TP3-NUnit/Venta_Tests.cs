﻿using IDS_TP3;
using Moq;

namespace IDS_TP3_NUnit
{
	public class Venta_Tests
	{
		private Mock<Producto> producto;

		[OneTimeSetUp]
		public void Setup()
		{
			producto = new Mock<Producto>();
			producto.Object.ID = 10;
		}

		/// <summary>
		/// Agregar producto nuevo a la venta
		/// </summary>
		[Test]
		public void AgregarProducto_Nuevo()
		{
			var venta = new Venta();

			venta.AgregarProducto(producto.Object);

			Assert.That(venta.LineasDeVenta, Has.Count.EqualTo(1));
			Assert.That(venta.LineasDeVenta[0].Cantidad, Is.EqualTo(1));
		}

		/// <summary>
		/// Agregar producto a la venta cuando ya está registrado en una linea de venta
		/// </summary>
		[Test]
		public void AgregarProducto_YaPresente()
		{
			var venta = new Venta()
			{
				LineasDeVenta = new List<LineaDeVenta>()
				{
					new LineaDeVenta(){Cantidad=5, Producto=producto.Object}
				}
			};

			venta.AgregarProducto(producto.Object);

			Assert.That(venta.LineasDeVenta, Has.Count.EqualTo(1));
			Assert.That(venta.LineasDeVenta[0].Cantidad, Is.EqualTo(6));
		}

		/// <summary>
		/// Quitar producto existente en una línea de venta
		/// </summary>
		[Test]
		public void QuitarProducto()
		{
			var venta = new Venta()
			{
				LineasDeVenta = new List<LineaDeVenta>()
				{
					new LineaDeVenta(){Cantidad=5, Producto=producto.Object}
				}
			};

			venta.QuitarProducto(producto.Object.ID);

			Assert.That(venta.LineasDeVenta, Has.Count.EqualTo(0));
		}
	}
}