using IDS_TP3;

namespace IDS_TP3_NUnit
{
    public class PruebasUnitarias_ReglasDeDescuento
    {

        [Test]
        public void CalcularDescuento_TotalInvalido()
        {
            var regla = new ReglaDeDescuento();
            double total = -100;

            try
            {
                var descuento = regla.Calcular(total);
                Assert.Fail();
            }
            catch (Exception exc)
            {
                Assert.That(exc.Message, Is.EqualTo("El total debe ser mayor a 0"));
            }
        }

        [Test]
        public void CalcularDescuento_TotalMenorA5k()
        {
            var regla = new ReglaDeDescuento();
            double total = 2500;

            var descuento = regla.Calcular(total);

            Assert.That(descuento, Is.EqualTo(0));
        }

        [Test]
        public void CalcularDescuento_TotalEntre5kY10k()
        {
            var regla = new ReglaDeDescuento();
            double total = 7500;

            var descuento = regla.Calcular(total);

            Assert.That(descuento, Is.EqualTo(225));
        }

        [Test]
        public void CalcularDescuento_TotalEntre10kY25k()
        {
            var regla = new ReglaDeDescuento();
            double total = 15000;

            var descuento = regla.Calcular(total);

            Assert.That(descuento, Is.EqualTo(750));
        }

        [Test]
        public void CalcularDescuento_TotalMayorA25k()
        {
            var regla = new ReglaDeDescuento();
            double total = 50000;

            var descuento = regla.Calcular(total);

            Assert.That(descuento, Is.EqualTo(5000));
        }
    }
}