﻿using IDS_TP3;
using System.Linq;

namespace IDS_TP3_Datos
{
    public class BaseDeDatosEnMemoria : IBaseDeDatos
    {
        private readonly List<Articulo> articulos;
        private readonly List<Producto> productos;

        public BaseDeDatosEnMemoria()
        {
            articulos = new List<Articulo>();
            productos = new List<Producto>();
        }

        public Articulo? BuscarArticulo(long codigo)
        {
            var resultado = articulos.Find((a)=>a.Codigo == codigo);
            return resultado;
        }

        public void RegistrarProducto(Producto producto)
        {
            productos.Add(producto);
        }
        public void RegistrarArticulo(Articulo articulo)
        {
            if (articulo.EsValido())
            {
                articulos.Add(articulo);
            }
            else
            {
                throw new ArgumentException("Datos incorrectos");
            }
        }

        public int GetStock(long codigoArticulo, string talle, string color)
        {
            foreach (var producto in productos)
            {
                if (producto.Articulo?.Codigo==codigoArticulo
                    && producto.Talle?.Descripcion == talle
                    && producto.Color?.Descripcion == color)
                {
                    return producto.Stock;
                }
            }
            throw new Exception("Producto no encontrado");
        }
    }

    public interface IBaseDeDatos
    {
        void RegistrarArticulo(Articulo articulo);

        void RegistrarProducto(Producto producto);

        Articulo? BuscarArticulo(long codigo);

        int GetStock(long codigoArticulo, string talle, string color);
    }
}