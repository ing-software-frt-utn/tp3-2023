﻿using IDS_TP3;
using IDS_TP3_Datos;
using NUnit.Framework;
using System.Text;
using TechTalk.SpecFlow.Assist;

namespace IDS_TP3_Gherkin.StepDefinitions
{
    [Binding]
    public sealed class AltaDeArticulosStepDefinition
    {
        private Empleado empleado;
        private Articulo articulo;

        [Given(@"que un usuario administrador este autenticado")]
        public void GivenQueUnUsuarioAdministradorEsteAutenticado()
        {
            empleado = new Empleado()
            {
                Apellido = "Apesao",
                Nombre = "Martin",
                Contrasenia = "bdd2023",
                Usuario = "Mapesoa",
                FechaDeNacimiento = DateTime.Now,
                Legajo = 1304,
                Rol = Rol.Administrativo
            };
        }

        [When(@"se registra un articulo con los siguientes datos")]
        public void WhenSeRegistraUnArticuloConLosSiguientesDatos(Table table)
        {
            var row = table.Rows[0];
            articulo = new Articulo()
            {
                Codigo = row.GetInt64("Codigo"),
                Descripcion = row.GetString("Descripcion"),
                Costo = row.GetDouble("Costo"),
                MargenDeGanancia = row.GetDouble("MargenGanancia"),
                IVA = row.GetDouble("IVA")
            };
        }

        [Then(@"se debe mostrar un mensaje de error")]
        public void ThenSeDebeMostrarUnMensajeDeError()
        {
            IBaseDeDatos baseDeDatos = new BaseDeDatosEnMemoria();
            try
            {
                baseDeDatos.RegistrarArticulo(articulo);
            }catch(ArgumentException ex)
            {
                Assert.AreEqual(ex.Message, "Datos incorrectos");
            }
        }

        [Then(@"el articulo se registra correctamente")]
        public void ThenElArticuloSeRegistraCorrectamente()
        {
            IBaseDeDatos baseDeDatos = new BaseDeDatosEnMemoria();
            baseDeDatos.RegistrarArticulo(articulo);
            Assert.NotNull(baseDeDatos.BuscarArticulo(articulo.Codigo));
        }

    }
}
