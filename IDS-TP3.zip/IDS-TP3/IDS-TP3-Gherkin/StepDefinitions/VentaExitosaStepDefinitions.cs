﻿using IDS_TP3;
using IDS_TP3_Datos;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow.Assist;

namespace IDS_TP3_Gherkin.StepDefinitions
{
    [Binding]
    public sealed class VentaExitosaStepDefinitions
    {
        private Empleado empleado;
        private Venta venta;

        private IBaseDeDatos baseDeDatos;

        private long codigoArticulo;
        private string talleSeleccionado;
        private string colorSeleccionado;
        [Given(@"que un usuario vendedor este autenticado")]
        public void GivenQueUnUsuarioVendedorEsteAutenticado()
        {
            empleado = new Empleado()
            {
                Apellido = "Britto",
                Nombre = "Patricio",
                Contrasenia = "bdd2023",
                Usuario = "PBritto",
                FechaDeNacimiento = DateTime.Now,
                Legajo = 1304,
                Rol = Rol.Vendedor
            };
        }

        [Given(@"existe una venta iniciada")]
        public void GivenExisteUnaVentaIniciada()
        {
            venta = new Venta()
            {
                Fecha = DateTime.Now,
                NumVenta = 1
            };
        }

        [Given(@"existe el producto con datos:")]
        public void GivenExisteElProductoConDatos(Table table)
        {
            var row = table.Rows[0];
            var categoria = new Categoria() { Descripcion = row.GetString("Categoria") };
            var marca = new Marca() { Descripcion = row.GetString("Marca") };
            var color = new Color() { Descripcion = row.GetString("Color") };
            var talle = new Talle() { Descripcion = row.GetString("Talle") };
            
            codigoArticulo = row.GetInt64("Codigo");
            var articulo = new Articulo()
            {
                Categoria = categoria,
                Marca = marca,
                Codigo = codigoArticulo,
                Descripcion = row.GetString("Descripcion")
            };
            var producto = new Producto()
            {
                Articulo = articulo,
                Stock = row.GetInt32("Stock"),
                Color = color,
                Talle = talle
            };

            baseDeDatos = new BaseDeDatosEnMemoria();
            baseDeDatos.RegistrarProducto(producto);
        }

        [When(@"se selecciona el talle ""([^""]*)"" con color ""([^""]*)""")]
        public void WhenSeSeleccionaElTalleConColor(string talle, string color)
        {
            talleSeleccionado = talle;
            colorSeleccionado = color;
        }

        [Then(@"se debera mostrar la cantidad disponible de (.*) unidades")]
        public void ThenSeDeberaMostrarLaCantidadDisponible(int stockEsperado)
        {
            var stock = baseDeDatos.GetStock(codigoArticulo, talleSeleccionado, colorSeleccionado);
            Assert.AreEqual(stockEsperado, stock);
        }

    }
}
